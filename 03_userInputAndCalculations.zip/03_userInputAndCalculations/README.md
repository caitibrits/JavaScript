# Instructions:

For the CodeSpace IWA User Input and Calculations challenge you can simply use the download zip option when clicking the code button and copy the files in 
this repo into your project (create your own project and copy the files over).

Once the files are copied you can continue working on your solution to the challenge

Goodluck and don't forget to commit regularly to your GitHub account.
